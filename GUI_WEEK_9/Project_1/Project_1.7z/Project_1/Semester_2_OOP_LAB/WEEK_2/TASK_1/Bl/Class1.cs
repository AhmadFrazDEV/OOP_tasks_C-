﻿using System;
using System.Collections.Generic;
using System.Text;

namespace login.Bl
{
    class Class1
    {
        public string name;
        public string department;
        public string Hostilze;
        public float gpa;
        public int Roll_Number;
    }
}
